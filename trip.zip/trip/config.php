<?php
config.php

header("Content-Type: application/json; charset=UTF-8");

$DB_HOST = "localhost";
$DB_NAME = "tourease_db";
$DB_USER = "root";
$DB_PASS = ""; // set your password

try {
  $pdo = new PDO(
    "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
    $DB_USER,
    $DB_PASS,
    [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]
  );
} catch (Exception $e) {
  http_response_code(500);
  echo json_encode(["error" => "Database connection failed"]);
  exit;
}

function read_json() {
  $data = json_decode(file_get_contents("php://input"), true);
  return is_array($data) ? $data : [];
}
